
import './App.css';
import OutlookMail from './components/OutlookMail';

function App() {
  return (
    <div className="App">
      <OutlookMail />
    </div>
  );
}

export default App;
